const assert = require('assert')
const {MerkleTree} = require('../src/merkle_tree')
const {MerkleNode} = require('../src/merkle_node')
const {secureHash} = require('../src/util')

describe('MerkleTree', function () {
  const mt = new MerkleTree()
 
  var parArr=[];
  describe('build tree with 6 leaves', function () {
    //const nodes = ['hi', 'there', 'what', 'is', 'up', '?']
   
    const nodes = ['1', '2', '3', '4', '5', '6','7','8','9'];


    const mt = new MerkleTree()
    mt.nodes = mt.leaves = nodes.map(s => new MerkleNode(s))
    mt.buildTree()
  const parentsData=[];
    console.log("Root Node : " +mt.rootNode.hash);
    for(i=0;i<mt.nodes.length;i++)
    {
    console.log("leaves Node : " +mt.nodes[i].hash);
    }
    console.log("leaves Node : " +mt.consistencyProof(9));
    it('verify consistency audit proof', function () {
      const cp = mt.consistencyProof(6)
      const cap = mt.consistencyAuditProof(cp[cp.length - 1].hash)
      const cap1 = mt.consistencyAuditProof(secureHash('6'))
      console.log("build audit prooofff 6")
      console.log(cap1);
      console.log("build audit proooffffff 6")
      console.log(cap);
      var val=[];
      // for (let i = 0; i < 6; i ++) {
      //  // const right = (i + 1 < nodes.length) ? nodes[i + 1] : null
      //   val=cap1.hash;
      //   parentsData.push(cap1.hash);
      // }
    var dd= getParRecur(cap1)
    console.log("Find the traverse for 6 : "+ secureHash('6'))
    console.log("Build travesrse 6")
      console.log(dd)

console.log("Modify tree")
const nodes = ['11', '12','13'];
//mt.tree = mt.leaves = nodes.map(s => new MerkleNode(s))
//mt.addTree(mt.tree)

//const cap12 = mt.consistencyAuditProof(secureHash('11'))

  //console.log(cap12);
     // assert.equal(mt.verifyAuditProof(mt.rootNode.hash, cp[cp.length - 1].hash, cap), true)
     
    })
   
function getParRecur(par)
{
 
if(par.parent!=null)
{
  parArr.push(par.parent.hash)
  return getParRecur(par.parent)
  
}
else
{
  
  return parArr;
}

}
    it('Audit trail ', function () {
      const existingHash = secureHash('3')
      const cp = mt.auditProof(existingHash)
      
      console.log("build audit traillllll")
     // console.log(cp);
     // assert.equal(mt.verifyAuditProof(mt.rootNode.hash, cp[cp.length - 1].hash, cap), true)
     
    })
  
  
  describe('audit proof on this tree', function () {
    const existingHash = secureHash('4')
    const nonExistingHash = secureHash('5535')
    it('audit proof of non-existing node should return empty list', function () {
      assert.equal(mt.auditProof(nonExistingHash).length, 0)
      console.log("keyword not available")
      console.log(mt.auditProof(nonExistingHash).length)
      
    })
    it('audit proof of an existing leaf should be non empty', function () {
      assert.notEqual(mt.auditProof(existingHash).length, 0)
      console.log("keyword aavailable")
      console.log(mt.auditProof(existingHash))
      console.log(mt.auditProof(existingHash).length)
    })
    it('verify audit proof returns true for 4', function () {
      const trail = mt.auditProof(existingHash)
      assert.equal(mt.verifyAuditProof(mt.rootNode.hash, existingHash, trail), true)
      console.log(" verify audit proof returns true for 4 keyword aavailable")
      console.log(mt.verifyAuditProof(mt.rootNode.hash, existingHash, trail))
    })
    // it('verify audit proof returns true for 3', function () {
    //   const trail = mt.auditProof(secureHash('3'))
    //   assert.equal(mt.verifyAuditProof(mt.rootNode.hash, secureHash('3'), trail), true)
    // })
  })
  })
})
